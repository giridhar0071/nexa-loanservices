package com.nexabank.loanservices;

import com.nexabank.loanservices.config.ServicesProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;

@SpringBootApplication
public class LoanservicesApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoanservicesApplication.class, args);
	}

}
