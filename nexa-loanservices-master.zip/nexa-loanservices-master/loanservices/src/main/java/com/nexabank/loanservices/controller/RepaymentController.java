package com.nexabank.loanservices.controller;

import com.nexabank.loanservices.dto.ApprovedRepaymentCreateRequest;
import com.nexabank.loanservices.dto.RepaymentPlanResponse;
import com.nexabank.loanservices.service.RepaymentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.UUID;

@RestController
@RequestMapping("/api/v1/repayments")
public class RepaymentController {

    private final RepaymentService repaymentService;

    public RepaymentController(RepaymentService repaymentService) {
        this.repaymentService = repaymentService;
    }

    @PostMapping("/create-options")
    public ResponseEntity<RepaymentPlanResponse> createRepaymentOptions(
            @RequestBody ApprovedRepaymentCreateRequest request) {
        return ResponseEntity.ok(repaymentService.createRepaymentOptions(request));
    }

    @GetMapping("/{loanId}")
    public ResponseEntity<RepaymentPlanResponse> getRepaymentPlan(@PathVariable UUID loanId) {
        return ResponseEntity.ok(repaymentService.getRepaymentPlanByLoanId(loanId));
    }
}
