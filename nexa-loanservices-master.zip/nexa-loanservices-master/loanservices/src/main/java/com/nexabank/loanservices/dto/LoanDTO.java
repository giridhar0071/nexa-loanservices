package com.nexabank.loanservices.dto;

import java.math.BigDecimal;
import java.util.UUID;

public class LoanDTO {
    private UUID loanId;
    private BigDecimal sanctionAmount;

    public UUID getLoanId() { return loanId; }
    public void setLoanId(UUID loanId) { this.loanId = loanId; }

    public BigDecimal getSanctionAmount() { return sanctionAmount; }
    public void setSanctionAmount(BigDecimal sanctionAmount) { this.sanctionAmount = sanctionAmount; }
}
