package com.nexabank.loanservices.entity;

import jakarta.persistence.*;
import org.hibernate.annotations.GenericGenerator;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.UUID;

@Entity
@Table(name = "approved_loans_repayment_options", schema = "loanschema")
public class RepaymentPlan {

    @Id
    @GeneratedValue(generator = "UUID")
    @GenericGenerator(name = "UUID", strategy = "org.hibernate.id.UUIDGenerator")
    @Column(name = "repayment_id", updatable = false, nullable = false)
    private UUID repaymentId;

    @Column(name = "loan_id", nullable = false)
    private UUID loanId;

    @Column(name = "apr", nullable = false, precision = 5, scale = 2)
    private BigDecimal apr;

    @Column(name = "months", nullable = false)
    private int months;

    @Column(name = "monthly_payments", nullable = false, precision = 12, scale = 2)
    private BigDecimal monthlyInstallment;

    @Column(name = "total_payable_amount", nullable = false, precision = 12, scale = 2)
    private BigDecimal totalRepayment;

    @Column(name = "total_principal_amount", nullable = false, precision = 12, scale = 2)
    private BigDecimal totalPrincipalAmount;

    @Column(name = "updated_at", nullable = false)
    private OffsetDateTime updatedAt = OffsetDateTime.now();

    // Constructors
    public RepaymentPlan() {}

    public RepaymentPlan(UUID loanId, BigDecimal apr, int months,
                         BigDecimal monthlyInstallment, BigDecimal totalRepayment,
                         BigDecimal totalPrincipalAmount) {
        this.loanId = loanId;
        this.apr = apr;
        this.months = months;
        this.monthlyInstallment = monthlyInstallment;
        this.totalRepayment = totalRepayment;
        this.totalPrincipalAmount = totalPrincipalAmount;
    }

    // Getters and setters

    public UUID getRepaymentId() {
        return repaymentId;
    }

    public UUID getLoanId() {
        return loanId;
    }

    public void setLoanId(UUID loanId) {
        this.loanId = loanId;
    }

    public BigDecimal getApr() {
        return apr;
    }

    public void setApr(BigDecimal apr) {
        this.apr = apr;
    }

    public int getMonths() {
        return months;
    }

    public void setMonths(int tenureMonths) {
        this.months = tenureMonths;
    }

    public BigDecimal getMonthlyInstallment() {
        return monthlyInstallment;
    }

    public void setMonthlyInstallment(BigDecimal monthlyInstallment) {
        this.monthlyInstallment = monthlyInstallment;
    }

    public BigDecimal getTotalRepayment() {
        return totalRepayment;
    }

    public void setTotalRepayment(BigDecimal totalRepayment) {
        this.totalRepayment = totalRepayment;
    }

    public BigDecimal getTotalPrincipalAmount() {
        return totalPrincipalAmount;
    }

    public void setTotalPrincipalAmount(BigDecimal totalPrincipalAmount) {
        this.totalPrincipalAmount = totalPrincipalAmount;
    }

    public OffsetDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(OffsetDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }
}
