package com.nexabank.loanservices.dto;

import java.math.BigDecimal;
import java.util.UUID;

import java.math.BigDecimal;
import java.util.UUID;

public class RepaymentPlanResponse {
    private UUID loanId;
    private BigDecimal apr;
    private int months;
    private BigDecimal monthlyInstallment;
    private BigDecimal totalPrincipalAmount;
    private BigDecimal totalRepayment;

    public RepaymentPlanResponse(UUID loanId, BigDecimal apr, int months,
                                 BigDecimal monthlyInstallment, BigDecimal totalPrincipalAmount,
                                 BigDecimal totalRepayment) {
        this.loanId = loanId;
        this.apr = apr;
        this.months = months;
        this.monthlyInstallment = monthlyInstallment;
        this.totalPrincipalAmount = totalPrincipalAmount;
        this.totalRepayment = totalRepayment;
    }

    public UUID getLoanId() {
        return loanId;
    }

    public void setLoanId(UUID loanId) {
        this.loanId = loanId;
    }

    public BigDecimal getApr() {
        return apr;
    }

    public void setApr(BigDecimal apr) {
        this.apr = apr;
    }

    public int getMonths() {
        return months;
    }

    public void setMonths(int months) {
        this.months = months;
    }

    public BigDecimal getMonthlyInstallment() {
        return monthlyInstallment;
    }

    public void setMonthlyInstallment(BigDecimal monthlyInstallment) {
        this.monthlyInstallment = monthlyInstallment;
    }

    public BigDecimal getTotalPrincipalAmount() {
        return totalPrincipalAmount;
    }

    public void setTotalPrincipalAmount(BigDecimal totalPrincipalAmount) {
        this.totalPrincipalAmount = totalPrincipalAmount;
    }

    public BigDecimal getTotalRepayment() {
        return totalRepayment;
    }

    public void setTotalRepayment(BigDecimal totalRepayment) {
        this.totalRepayment = totalRepayment;
    }
}
