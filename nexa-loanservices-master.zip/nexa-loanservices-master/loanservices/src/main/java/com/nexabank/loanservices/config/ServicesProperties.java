package com.nexabank.loanservices.config;

import org.springframework.boot.context.properties.ConfigurationProperties;


@ConfigurationProperties(prefix = "services")
public class ServicesProperties {
    public static class Endpoint {
        private String baseUrl;
        public String getBaseUrl() { return baseUrl; }
        public void setBaseUrl(String baseUrl) { this.baseUrl = baseUrl; }
    }

    private Endpoint loanapplication = new Endpoint();

    public Endpoint getLoanapplication() { return loanapplication; }
    public void setLoanapplication(Endpoint loanapplication) { this.loanapplication = loanapplication; }
}
