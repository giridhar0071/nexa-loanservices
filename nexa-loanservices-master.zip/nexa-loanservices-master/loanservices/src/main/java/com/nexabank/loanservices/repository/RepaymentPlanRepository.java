package com.nexabank.loanservices.repository;

import com.nexabank.loanservices.entity.RepaymentPlan;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.UUID;

public interface RepaymentPlanRepository extends JpaRepository<RepaymentPlan, UUID> {
    RepaymentPlan findByLoanId(UUID loanId);
}
