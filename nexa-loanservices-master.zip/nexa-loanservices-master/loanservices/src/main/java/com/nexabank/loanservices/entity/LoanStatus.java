package com.nexabank.loanservices.entity;

public enum LoanStatus {
    DRAFT,
    SUBMITTED,
    PROCESSING,
    APPROVED,
    REJECTED,
    ACCEPTED,
    DENIED
}
