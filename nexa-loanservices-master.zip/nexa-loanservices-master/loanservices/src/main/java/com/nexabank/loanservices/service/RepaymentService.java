package com.nexabank.loanservices.service;

import com.nexabank.loanservices.dto.*;
import com.nexabank.loanservices.entity.RepaymentPlan;
import com.nexabank.loanservices.repository.RepaymentPlanRepository;
import com.nexabank.loanservices.config.ServicesProperties;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.UUID;
@Service
public class RepaymentService {

    private final RestTemplate restTemplate;
    private final RepaymentPlanRepository repo;
    private final ServicesProperties props;

    public RepaymentService(RestTemplate restTemplate,
                            RepaymentPlanRepository repo,
                            ServicesProperties props) {
        this.restTemplate = restTemplate;
        this.repo = repo;
        this.props = props;
    }

    public RepaymentPlanResponse createRepaymentOptions(ApprovedRepaymentCreateRequest request) {
        String url = props.getLoanapplication().getBaseUrl()
                + "/api/v1/loanapplications/" + request.getLoanId();

        LoanDTO loan = restTemplate.getForObject(url, LoanDTO.class);
        if (loan == null || loan.getSanctionAmount() == null) {
            throw new RuntimeException("Loan not found for id " + request.getLoanId());
        }

        BigDecimal principal = loan.getSanctionAmount();
        int months = request.getMonths();
        BigDecimal apr = request.getApr();

        BigDecimal emi = computeEMI(principal, apr, months);
        BigDecimal totalPayable = emi.multiply(BigDecimal.valueOf(months));

        RepaymentPlan entity = new RepaymentPlan(
                request.getLoanId(),
                apr,
                months,
                emi.setScale(2, RoundingMode.HALF_UP),
                totalPayable.setScale(2, RoundingMode.HALF_UP), // total_payable_amount
                principal.setScale(2, RoundingMode.HALF_UP)   // total_principal_amount
        );
        repo.save(entity);

        return new RepaymentPlanResponse(
                entity.getLoanId(),
                entity.getApr(),
                entity.getMonths(),
                entity.getMonthlyInstallment(),
                entity.getTotalPrincipalAmount(),
                entity.getTotalRepayment()
        );
    }

    public RepaymentPlanResponse getRepaymentPlanByLoanId(UUID loanId) {
        RepaymentPlan entity = repo.findByLoanId(loanId);
        if (entity == null) {
            throw new RuntimeException("Repayment plan not found for loanId " + loanId);
        }
        return new RepaymentPlanResponse(
                entity.getLoanId(),
                entity.getApr(),
                entity.getMonths(),
                entity.getMonthlyInstallment(),
                entity.getTotalPrincipalAmount(),
                entity.getTotalRepayment()
        );
    }

    private BigDecimal computeEMI(BigDecimal principal, BigDecimal apr, int months) {
        double P = principal.doubleValue();
        double r = apr.doubleValue() / 12 / 100;
        double n = months;
        double emi = (P * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
        return BigDecimal.valueOf(emi);
    }
}