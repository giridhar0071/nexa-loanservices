package com.nexabank.loanservices.dto;

import java.math.BigDecimal;
import java.util.UUID;

public class ApprovedRepaymentCreateRequest {
    private UUID loanId;
    private int months;
    private BigDecimal apr;

    public UUID getLoanId() { return loanId; }
    public void setLoanId(UUID loanId) { this.loanId = loanId; }

    public int getMonths() { return months; }
    public void setMonths(int months) { this.months = months; }

    public BigDecimal getApr() { return apr; }
    public void setApr(BigDecimal apr) { this.apr = apr; }
}
