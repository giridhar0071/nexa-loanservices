package com.nexa.loanapplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoanapplicationApplicationTests {

	@Test
	void contextLoads() {
	}

}
