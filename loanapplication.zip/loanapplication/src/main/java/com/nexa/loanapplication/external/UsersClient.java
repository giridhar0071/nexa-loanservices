package com.nexa.loanapplication.external;

import com.nexa.loanapplication.config.ServicesProperties;
import com.nexa.loanapplication.dto.external.UserDTO;
import com.nexa.loanapplication.exception.BadRequestException;
import com.nexa.loanapplication.exception.NotFoundException;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestClientException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.UUID;

@Component
public class UsersClient {
    private static final String BASE = "/api/users";

    private final RestTemplate rest;
    private final ServicesProperties props;

    private static final Logger log = LoggerFactory.getLogger(UsersClient.class);

    public UsersClient(RestTemplate rest, ServicesProperties props) {
        this.rest = rest;
        this.props = props;
    }

    public UserDTO getById(UUID id) {
        String url = props.getUsers().getBaseUrl() + "/api/users/" + id;
        try {
            UserDTO dto = rest.getForObject(url, UserDTO.class);
            if (dto == null) throw new NotFoundException("User not found: " + id);
            log.debug("UsersClient.getById -> {}", dto.debug()); // see salary/score at runtime
            return dto;
        } catch (RestClientResponseException e) {
            if (e.getRawStatusCode() == 404) throw new NotFoundException("User not found: " + id);
            throw new BadRequestException("Users service error: " + e.getRawStatusCode() + " " + e.getResponseBodyAsString());
        } catch (RestClientException e) {
            throw new BadRequestException("Users service unreachable: " + e.getMessage());
        }
    }

    public boolean exists(UUID id) {
        try {
            return getById(id) != null;
        } catch (NotFoundException e) {
            return false;
        }
    }
}
