package com.nexa.loanapplication.service;

import com.nexa.loanapplication.config.ServicesProperties;
import com.nexa.loanapplication.domain.LoanApplication;
import com.nexa.loanapplication.domain.LoanStatus;
import com.nexa.loanapplication.dto.external.EligibilityRuleDTO;
import com.nexa.loanapplication.dto.external.LoanPointDTO;
import com.nexa.loanapplication.dto.external.UserDTO;
import com.nexa.loanapplication.dto.requests.*;
import com.nexa.loanapplication.dto.responses.LoanApplicationResponse;
import com.nexa.loanapplication.exception.BadRequestException;
import com.nexa.loanapplication.exception.ConflictException;
import com.nexa.loanapplication.exception.NotFoundException;
import com.nexa.loanapplication.external.*;
import com.nexa.loanapplication.repository.LoanApplicationRepository;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.OffsetDateTime;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
@Service
public class LoanApplicationManager {

    private final LoanApplicationRepository repo;
    private final EligibilityClient eligibilityClient;
    private final PointsClient pointsClient;
    private final AuditLogClient auditLogClient;
    private final RepaymentOptionsClient repaymentClient;
    private final UsersClient usersClient; // <-- NEW
    private final ServicesProperties props;
    private static final Logger log = LoggerFactory.getLogger(UsersClient.class);
    public LoanApplicationManager(LoanApplicationRepository repo,
                                  EligibilityClient eligibilityClient,
                                  PointsClient pointsClient,
                                  AuditLogClient auditLogClient,
                                  RepaymentOptionsClient repaymentClient,
                                  UsersClient usersClient,
                                  ServicesProperties props) {
        this.repo = repo;
        this.eligibilityClient = eligibilityClient;
        this.pointsClient = pointsClient;
        this.auditLogClient = auditLogClient;
        this.repaymentClient = repaymentClient;
        this.usersClient = usersClient;                                 // <-- NEW
        this.props = props;
    }

    public Page<LoanApplicationResponse> list(int page, int size) {
        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        return repo.findAll(pageable).map(this::toResponse);
    }

    public LoanApplicationResponse getById(UUID loanId) {
        LoanApplication la = repo.findById(loanId).orElseThrow(() ->
                new NotFoundException("Loan not found: " + loanId));
        return toResponse(la);
    }

    /** POST /api/v1/loanapplications (create Draft) */
//    public LoanApplicationResponse create(CreateLoanApplicationRequest in) {
//        if (in.getRequestedAmount().compareTo(BigDecimal.ZERO) <= 0) {
//            throw new BadRequestException("requestedAmount must be > 0");
//        }
//        // === NEW: verify user exists + baseline eligibility from Users service ===
//        UserDTO user = usersClient.getById(in.getUserId()); // throws 404 -> bubbles as NotFound
//        validateBaselineFromUser(user); // salary / creditScore quick screen
////        // Resolve eligibility rule (from other service)
////        var rule = eligibilityClient.getById(in.getLoanEid());
////        if (!rule.getLoanTypeId().equals(in.getLoanTypeId())) {
////            throw new BadRequestException("loanTypeId does not match eligibility rule's loanTypeId");
////        }
//        var rules = eligibilityClient.listByLoanType(in.getLoanTypeId());
//        if (rules.isEmpty()) {
//            throw new NotFoundException("No eligibility rules configured for loan type");
//        }
//
//        // 3) Filter by user + amount
//        var matching = rules.stream().filter(r ->
//                // ensure loan type matches
//                in.getLoanTypeId().equals(r.getLoanTypeId()) &&
//                        // salary
//                r.getMinSalary() != null && user.getSalary() != null &&
//                        user.getSalary().compareTo(r.getMinSalary()) >= 0 &&
//                        // credit score within band
//                        user.getCreditScore() != null &&
//                        user.getCreditScore() >= r.getMinCreditScore() &&
//                        (r.getMaxCreditScore() == null || user.getCreditScore() <= r.getMaxCreditScore()) &&
//                        // amount within product cap
//                        (r.getMaxLoanAmount() == null || in.getRequestedAmount().compareTo(r.getMaxLoanAmount()) <= 0)
//        ).toList();
//        if (matching.isEmpty()) {
//            throw new BadRequestException("No eligibility rule matches applicant profile and requested amount.");
//        }
//
//        // 4) Pick best: prefer direct-approve, lowest APR; else points, tightest band
//        EligibilityRuleDTO chosen = matching.stream()
//                .sorted((a, b) -> {
//                    // direct first
//                    int aDirect = (a.getLoanPointId() == null) ? 0 : 1;
//                    int bDirect = (b.getLoanPointId() == null) ? 0 : 1;
//                    if (aDirect != bDirect) return Integer.compare(aDirect, bDirect);
//
//                    // if both direct, compare APR asc (nulls last)
//                    if (a.getLoanPointId() == null && b.getLoanPointId() == null) {
//                        BigDecimal aApr = a.getApr(); BigDecimal bApr = b.getApr();
//                        if (aApr == null && bApr == null) return 0;
//                        if (aApr == null) return 1;
//                        if (bApr == null) return -1;
//                        return aApr.compareTo(bApr);
//                    }
//
//                    // else both are points-based: pick tightest band (higher minCreditScore first)
//                    return Integer.compare(
//                            b.getMinCreditScore() != null ? b.getMinCreditScore() : 0,
//                            a.getMinCreditScore() != null ? a.getMinCreditScore() : 0
//                    );
//                })
//                .findFirst()
//                .orElseThrow(() -> new BadRequestException("No suitable eligibility rule found."));
//
//        LoanApplication la = new LoanApplication();
//        la.setLoanId(UUID.randomUUID());
//        la.setUserId(in.getUserId());
//        la.setLoanTypeId(in.getLoanTypeId());
//        la.setLoanEid(chosen.getLoanEid());
//        la.setRequestedAmount(in.getRequestedAmount());
//        la.setStatus(LoanStatus.DRAFT);
//
//        log.debug("Chosen rule: eid={}, loanTypeId={}, apr={}, pointId={}",
//                chosen.getLoanEid(), chosen.getLoanTypeId(), chosen.getApr(), chosen.getLoanPointId());
//
//        // we don't price yet; pricing occurs during approval
//        la = repo.save(la);
//        return toResponse(la);
//    }

    public LoanApplicationResponse create(CreateLoanApplicationRequest in) {
        if (in.getRequestedAmount().compareTo(BigDecimal.ZERO) <= 0) {
            throw new BadRequestException("requestedAmount must be > 0");
        }

// Create basic draft without checking eligibility or fetching rule
        LoanApplication la = new LoanApplication();
        la.setLoanId(UUID.randomUUID());
        la.setUserId(in.getUserId());
        la.setLoanTypeId(in.getLoanTypeId());
        la.setRequestedAmount(in.getRequestedAmount());
        la.setStatus(LoanStatus.DRAFT);
        la.setCreatedAt(OffsetDateTime.now());

        repo.save(la);
        return toResponse(la);
    }

    /** POST /api/v1/loanapplications/submit  (Draft -> Submitted) */
    public LoanApplicationResponse submit(SimpleLoanIdRequest in, String actor) {
        var la = mustFind(in.getLoanId());
        ensureStatus(la, LoanStatus.DRAFT, "Only Draft can be submitted");
        la.setStatus(LoanStatus.SUBMITTED);
        la.setSubmittedDate(new java.sql.Date(System.currentTimeMillis()));
        repo.save(la);
        auditLogClient.writeAudit(la.getLoanId(), la.getUserId(), LoanStatus.SUBMITTED, actor);
        return toResponseWithComputedPricing(la); // will compute pricing fields as null here
    }

//    /** POST /api/v1/loanapplications/approve (Processing -> Approved) */
//    public LoanApplicationResponse approve(ApproveRequest in, String actor) {
//        var la = mustFind(in.getLoanId());
//        ensureStatus(la, LoanStatus.SUBMITTED, "Only Submitted can be Approved");
//        if (la.getRequestedAmount().compareTo(BigDecimal.ZERO) < 0) {
//            throw new BadRequestException("sanctionAmount must be >= 0");
//        }
//
//        // Re-verify user exists + baseline (user might have been deleted/changed)
//        UserDTO user = usersClient.getById(la.getUserId());
//        validateBaselineFromUser(user);
//
//        System.out.println(la.getLoanId());
//        System.out.println(la.getUserId());
//        System.out.println("Actor is "+actor);
//        System.out.println("User id from userclient is "+user.getId());
//        // Fetch rule
//        var rule = eligibilityClient.getById(la.getLoanEid());
//
//        // Compute pricing in-memory
//        BigDecimal apr;
//        UUID loanPointId = rule.getLoanPointId();
//        BigDecimal pointsFee = BigDecimal.ZERO;
//        boolean financeFee = true; // policy
//        BigDecimal financedPrincipal = la.getRequestedAmount();
//
//        BigDecimal sanctionedAmount;
//
//        if (loanPointId != null) {
//            // Points used — APR is fixed
//            apr = new BigDecimal("12.50");
//
//            // Get point percentage config
//            var lp = pointsClient.getById(loanPointId);
//
//            // Convert % to decimal fraction
//            var feeFraction = lp.getPercentageOnLoanApproval();
////            Use this if our points is whole number like 6% if it's already in decimal don't divide
////                .divide(new BigDecimal("100"), 4, RoundingMode.HALF_UP); // gives 0.06
//
//            // Calculate fee = percentage × requested amount
//            pointsFee = la.getRequestedAmount()
//                    .multiply(feeFraction)
//                    .setScale(2, RoundingMode.HALF_UP);
//
//            // Subtract fee from requested amount to get sanctioned amount
//            sanctionedAmount = la.getRequestedAmount()
//                    .subtract(pointsFee)
//                    .setScale(2, RoundingMode.HALF_UP);
//
//        } else {
//            // No points, use APR from eligibility rule
//            if (rule.getApr() == null)
//                throw new BadRequestException("Eligibility rule APR missing for direct-approve band");
//
//            apr = rule.getApr().setScale(2, RoundingMode.HALF_UP);
//
//            // Full amount sanctioned
//            sanctionedAmount = la.getRequestedAmount().setScale(2, RoundingMode.HALF_UP);
//        }
//
//        // Persist only APPROVED columns
//        la.setSanctionAmount(sanctionedAmount);
//        la.setApprovedAt(OffsetDateTime.now());
//        la.setStatus(LoanStatus.APPROVED);
//        repo.save(la);
//
//        auditLogClient.writeAudit(la.getLoanId(), la.getUserId(), LoanStatus.APPROVED, actor);
//
//        int months =in.getMonths(); // or pull from request/policy
//        repaymentClient.createRepaymentOptions(
//                new RepaymentOptionsClient.ApprovedRepaymentCreateRequest(
//                        la.getLoanId(), months, apr
//                )
//        );
//
//        // Return response with computed pricing fields populated
//        return toResponseWithComputedPricing(la, apr, loanPointId, pointsFee, financeFee, sanctionedAmount);
//    }

    public LoanApplicationResponse approve(ApproveRequest in, String actor) {
        var la = mustFind(in.getLoanId());
        ensureStatus(la, LoanStatus.SUBMITTED, "Only Submitted can be Approved");

        if (la.getRequestedAmount().compareTo(BigDecimal.ZERO) <= 0) {
            throw new BadRequestException("sanctionAmount must be >= 0");
        }

        // Re-verify user
        UserDTO user = usersClient.getById(la.getUserId());

        var salary = user.getSalary();
        var score = user.getCreditScore();

        if (salary == null || salary.compareTo(new BigDecimal("2000")) < 0 ||
                score == null || score < 500 || score > 850 ||
                (user.getStatus() != null && !"active".equalsIgnoreCase(user.getStatus()))) {

            return rejectDueToIneligibility(la, actor, "User failed baseline salary, score, or status check.");
        }
        // Fetch rules for the loan type
        var rules = eligibilityClient.listByLoanType(la.getLoanTypeId());
        if (rules.isEmpty()) {
            return rejectDueToIneligibility(la, actor, "No eligibility rules configured for loan type");
        }

        // Filter rules
        var matching = rules.stream().filter(r ->
                la.getLoanTypeId().equals(r.getLoanTypeId()) &&
                        r.getMinSalary() != null && user.getSalary() != null &&
                        user.getSalary().compareTo(r.getMinSalary()) >= 0 &&
                        user.getCreditScore() != null &&
                        user.getCreditScore() >= r.getMinCreditScore() &&
                        (r.getMaxCreditScore() == null || user.getCreditScore() <= r.getMaxCreditScore()) &&
                        (r.getMaxLoanAmount() == null || la.getRequestedAmount().compareTo(r.getMaxLoanAmount()) <= 0)
        ).toList();

        if (matching.isEmpty()) {
            return rejectDueToIneligibility(la, actor, "Applicant doesn't meet any eligibility rule.");
        }

        // Pick best rule
        EligibilityRuleDTO rule = matching.stream()
                .sorted((a, b) -> {
                    int aDirect = (a.getLoanPointId() == null) ? 0 : 1;
                    int bDirect = (b.getLoanPointId() == null) ? 0 : 1;
                    if (aDirect != bDirect) return Integer.compare(aDirect, bDirect);

                    if (a.getLoanPointId() == null && b.getLoanPointId() == null) {
                        BigDecimal aApr = a.getApr(), bApr = b.getApr();
                        if (aApr == null && bApr == null) return 0;
                        if (aApr == null) return 1;
                        if (bApr == null) return -1;
                        return aApr.compareTo(bApr);
                    }

                    return Integer.compare(
                            b.getMinCreditScore() != null ? b.getMinCreditScore() : 0,
                            a.getMinCreditScore() != null ? a.getMinCreditScore() : 0
                    );
                })
                .findFirst()
                .orElseThrow(() -> new BadRequestException("No suitable eligibility rule found."));
        // Pricing logic
        BigDecimal apr;
        UUID loanPointId = rule.getLoanPointId();
        BigDecimal pointsFee = BigDecimal.ZERO;
        boolean financeFee = true;
        BigDecimal financedPrincipal = la.getRequestedAmount();
        BigDecimal sanctionedAmount;

        if (loanPointId != null) {
            apr = new BigDecimal("12.50");
            var lp = pointsClient.getById(loanPointId);
            var feeFraction = lp.getPercentageOnLoanApproval();

            pointsFee = la.getRequestedAmount()
                    .multiply(feeFraction)
                    .setScale(2, RoundingMode.HALF_UP);

            sanctionedAmount = la.getRequestedAmount()
                    .subtract(pointsFee)
                    .setScale(2, RoundingMode.HALF_UP);

        } else {
            if (rule.getApr() == null)
                return rejectDueToIneligibility(la, actor, "Eligibility rule APR missing for direct-approve band");

            apr = rule.getApr().setScale(2, RoundingMode.HALF_UP);
            sanctionedAmount = la.getRequestedAmount().setScale(2, RoundingMode.HALF_UP);
        }

        // Update loan
        la.setLoanEid(rule.getLoanEid());
        la.setSanctionAmount(sanctionedAmount);
        la.setApprovedAt(OffsetDateTime.now());
        la.setStatus(LoanStatus.APPROVED);
        repo.save(la);

        auditLogClient.writeAudit(la.getLoanId(), la.getUserId(), LoanStatus.APPROVED, actor);

        int months = in.getMonths();
        repaymentClient.createRepaymentOptions(
                new RepaymentOptionsClient.ApprovedRepaymentCreateRequest(
                        la.getLoanId(), months, apr
                )
        );

        return toResponseWithComputedPricing(la, apr, loanPointId, pointsFee, financeFee, sanctionedAmount);
    }

    /** POST /api/v1/loanapplications/reject (Processing -> Rejected) */
    public LoanApplicationResponse reject(SimpleLoanIdRequest in, String actor) {
        LoanApplication la = mustFind(in.getLoanId());
        ensureStatus(la, LoanStatus.PROCESSING, "Only Processing can be Rejected");
        la.setStatus(LoanStatus.REJECTED);
        repo.save(la);
        auditLogClient.writeAudit(la.getLoanId(), la.getUserId(), LoanStatus.REJECTED, actor);
        return toResponse(la);
    }

    /** POST /api/v1/loanapplications/deny (Approved -> Denied) */
    public LoanApplicationResponse deny(SimpleLoanIdRequest in, String actor) {
        LoanApplication la = mustFind(in.getLoanId());
        ensureStatus(la, LoanStatus.APPROVED, "Only Approved can be Denied");
        la.setStatus(LoanStatus.DENIED);
        repo.save(la);
        auditLogClient.writeAudit(la.getLoanId(), la.getUserId(), LoanStatus.DENIED, actor);
        return toResponse(la);
    }

    /** DELETE /api/v1/loanapplications?id=<loanId> (Draft only) */
    public void deleteDraft(UUID loanId) {
        LoanApplication la = mustFind(loanId);
        ensureStatus(la, LoanStatus.DRAFT, "Only Draft can be deleted");
        repo.delete(la);
    }

    /** PUT /api/v1/loanapplications (update Draft only) */
    public LoanApplicationResponse updateDraft(UpdateDraftRequest in) {
        LoanApplication la = mustFind(in.getLoanId());
        ensureStatus(la, LoanStatus.DRAFT, "Only Draft can be updated");

        if (in.getRequestedAmount().compareTo(BigDecimal.ZERO) <= 0) {
            throw new BadRequestException("requestedAmount must be > 0");
        }
        la.setLoanTypeId(in.getLoanTypeId());
        la.setRequestedAmount(in.getRequestedAmount());
        repo.save(la);
        return toResponse(la);
    }

    // --- Helpers ---
    private LoanApplication mustFind(UUID id) {
        return repo.findById(id).orElseThrow(() -> new NotFoundException("Loan not found: " + id));
    }
    private void ensureStatus(LoanApplication la, LoanStatus required, String msg) {
        if (la.getStatus() != required) throw new ConflictException(msg);
    }
    private LoanApplicationResponse toResponse(LoanApplication la) {
        LoanApplicationResponse out = new LoanApplicationResponse();
        // copy persisted fields only
        out.setLoanId(la.getLoanId());
        out.setUserId(la.getUserId());
        out.setLoanTypeId(la.getLoanTypeId());
        out.setLoanEid(la.getLoanEid());
        out.setStatus(la.getStatus());
        out.setRequestedAmount(la.getRequestedAmount());
        out.setSanctionAmount(la.getSanctionAmount());
        out.setSubmittedDate(la.getSubmittedDate());
        out.setCreatedAt(la.getCreatedAt());
        out.setApprovedAt(la.getApprovedAt());
        return out;
    }

    private LoanApplicationResponse toResponseWithComputedPricing(LoanApplication la) {
        return toResponseWithComputedPricing(la, null, null, null, null, null);
    }

    private LoanApplicationResponse toResponseWithComputedPricing(
            LoanApplication la,
            BigDecimal apr,
            UUID loanPointId,
            BigDecimal pointsFee,
            Boolean financeFee,
            BigDecimal financedPrincipal) {

        LoanApplicationResponse out = toResponse(la);
        if (apr != null) out.setApr(apr);
        if (loanPointId != null) out.setLoanPointId(loanPointId);
        if (pointsFee != null) out.setPointsFee(pointsFee);
        if (financeFee != null) out.setPointsFinanced(financeFee);
        if (financedPrincipal != null) out.setFinancedPrincipal(financedPrincipal);
        return out;
    }

    private LoanApplicationResponse rejectDueToIneligibility(LoanApplication la, String actor, String reason) {
        la.setStatus(LoanStatus.REJECTED);
        repo.save(la);
        auditLogClient.writeAudit(la.getLoanId(), la.getUserId(), LoanStatus.REJECTED, actor);
        throw new BadRequestException("Loan rejected: " + reason);
    }

//    private void validateBaselineFromUser(UserDTO user) {
//        // Global baseline derived from your schema constraints:
//        // - min_salary >= 2000 (global floor)
//        // - credit_score between 500 and 850
//        var salary = user.getSalary();
//        var score = user.getCreditScore();
//
//        if (salary == null || salary.compareTo(new BigDecimal("2000")) < 0) {
//            throw new BadRequestException("User does not meet minimum salary requirement (>= 2000).");
//        }
//        if (score == null || score < 500 || score > 850) {
//            throw new BadRequestException("User credit score must be between 500 and 850.");
//        }
//        // Optional: status check
//        if (user.getStatus() != null && !"active".equalsIgnoreCase(user.getStatus())) {
//            throw new BadRequestException("User is not active.");
//        }
//    }
}
