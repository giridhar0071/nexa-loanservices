package com.nexa.loanapplication.domain;

public enum LoanStatus {
    DRAFT,
    SUBMITTED,
    PROCESSING,
    APPROVED,
    REJECTED,
    ACCEPTED,
    DENIED
}
