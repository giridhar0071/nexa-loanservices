package com.nexa.loanapplication.external;

import com.nexa.loanapplication.config.ServicesProperties;
import com.nexa.loanapplication.dto.external.EligibilityRuleDTO;
import com.nexa.loanapplication.exception.BadRequestException;
import com.nexa.loanapplication.exception.NotFoundException;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.UUID;
import org.springframework.web.client.RestClientResponseException;
import org.springframework.web.client.RestClientException;


/** Calls GET /api/v1/loaneligibilityrules and /.../id?<loaneid> */
@Component
public class EligibilityClient {
    private final RestTemplate rest;
    private final ServicesProperties props;

    public EligibilityClient(RestTemplate rest, ServicesProperties props) {
        this.rest = rest; this.props = props;
    }

    public List<EligibilityRuleDTO> listAll() {
        String url = props.getEligibility().getBaseUrl() + "/api/v1/loaneligibilityrules";
        try {
            var arr = rest.getForObject(url, EligibilityRuleDTO[].class);
            return arr == null ? List.of() : List.of(arr);
        } catch (RestClientResponseException e) {
            if (e.getRawStatusCode() == 404) {
                throw new NotFoundException("Eligibility list endpoint not found at " + url);
            }
            throw new BadRequestException("Eligibility service error: " + e.getRawStatusCode() + " " + e.getResponseBodyAsString());
        } catch (RestClientException e) {
            throw new BadRequestException("Eligibility service unreachable: " + e.getMessage());
        }
    }


    public EligibilityRuleDTO getById(UUID loanEid) {
        // Excel had a small typo ("eligibilty"); we standardize to "eligibility"
        String url = props.getEligibility().getBaseUrl()
                + "/api/v1/loaneligibilityrules/rule/" + loanEid;
        EligibilityRuleDTO dto = rest.getForObject(url, EligibilityRuleDTO.class);
        if (dto == null) throw new NotFoundException("Eligibility rule not found: " + loanEid);
        return dto;
    }

    public List<EligibilityRuleDTO> listByLoanType(UUID loanTypeId) {
        // If your service supports query:
         String url = props.getEligibility().getBaseUrl() + "/api/v1/loaneligibilityrules/" + loanTypeId;
         var arr = rest.getForObject(url, EligibilityRuleDTO[].class);
         return arr == null ? List.of() : List.of(arr);

//        // Fallback: list all and filter client-side
//        return listAll().stream()
//                .filter(r -> loanTypeId.equals(r.getLoanTypeId()))
//                .toList();
    }
}
