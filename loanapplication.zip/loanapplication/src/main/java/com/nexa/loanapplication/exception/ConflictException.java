package com.nexa.loanapplication.exception;
public class ConflictException extends RuntimeException {
    public ConflictException(String m){ super(m); }
}
