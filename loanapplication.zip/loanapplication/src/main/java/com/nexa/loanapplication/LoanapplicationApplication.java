package com.nexa.loanapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LoanapplicationApplication {

	public static void main(String[] args) {
		SpringApplication.run(LoanapplicationApplication.class, args);
	}

}
