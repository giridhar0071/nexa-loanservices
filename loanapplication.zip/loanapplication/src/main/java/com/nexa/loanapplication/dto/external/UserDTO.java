package com.nexa.loanapplication.dto.external;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;
import java.util.UUID;

public class UserDTO {
    private UUID id;
    private String name;
    private String email;
    @JsonProperty("salary")
    @JsonAlias({"annualSalary", "annual_salary", "monthlySalary", "monthly_salary", "salary_amount"})
    private BigDecimal salary;  // <-- used for baseline check

    @JsonProperty("creditScore")
    @JsonAlias({"credit_score"})
    private Integer creditScore; // <-- used for baseline check
    private String status; // active/inactive, etc.

    public UUID getId() { return id; }
    public void setId(UUID id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public BigDecimal getSalary() { return salary; }
    public void setSalary(BigDecimal salary) { this.salary = salary; }
    public Integer getCreditScore() { return creditScore; }
    public void setCreditScore(Integer creditScore) { this.creditScore = creditScore; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @JsonIgnore
    public String debug() {
        return "UserDTO{id=%s, salary=%s, creditScore=%s, status=%s}"
                .formatted(id, salary, creditScore, status);
    }
}
